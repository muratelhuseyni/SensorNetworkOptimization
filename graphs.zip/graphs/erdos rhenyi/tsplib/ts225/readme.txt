ts225-N=225, tsp source

converted into a random graph using Erdos-rhenyi alg with p=0.3

N=225	E=7604	k=5